package com.travel.TourService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
